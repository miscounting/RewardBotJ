pwd=$(pwd)
java -DCONFIGDIR="$pwd/" -jar rewardbot.jar
